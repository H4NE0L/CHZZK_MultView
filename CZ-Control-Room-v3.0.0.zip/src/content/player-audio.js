"use strict";
(() => {
  // src/content/player-audio.js
  globalThis.CZPlayerAudio = { create({ findVideo, report }) {
    let desired = null, intentUntil = 0, pointer = null, timer = null, intentKind = "volume", disposed = false;
    const clearIntent = () => {
      intentUntil = 0;
      pointer = null;
    };
    const recoveries = [];
    const matches = (video) => desired && Math.abs(video.volume - desired.volume) < 1e-5 && video.muted === desired.muted;
    function apply(video) {
      if (disposed || !video || !desired) return;
      if (desired.muted && !video.muted) video.muted = true;
      if (Math.abs(video.volume - desired.volume) > 1e-5) video.volume = desired.volume;
      if (video.muted !== desired.muted) video.muted = desired.muted;
    }
    function recover() {
      if (disposed || timer) return;
      const now = Date.now();
      while (recoveries.length && now - recoveries[0] >= 1e3) recoveries.shift();
      const delay = recoveries.length >= 4 ? Math.max(50, 1e3 - (now - recoveries[0])) : 30;
      timer = setTimeout(() => {
        timer = null;
        const video = findVideo();
        if (video && desired && !matches(video)) {
          recoveries.push(Date.now());
          apply(video);
        }
      }, delay);
    }
    function setVolume(volume, muted) {
      if (disposed || !Number.isFinite(volume)) return false;
      const next = { volume: Math.max(0, Math.min(1, volume)), muted: typeof muted === "boolean" ? muted : volume <= 0 };
      const changed = !desired || next.volume !== desired.volume || next.muted !== desired.muted;
      desired = next;
      if (changed) {
        intentUntil = 0;
        pointer = null;
      }
      clearTimeout(timer);
      timer = null;
      const video = findVideo();
      if (!video) return false;
      if (changed || Date.now() >= intentUntil) apply(video);
      report(video, "command");
      return true;
    }
    function setMuted(muted) {
      const video = findVideo(), volume = desired?.volume ?? video?.volume ?? 1;
      return setVolume(!muted && volume <= 0 ? 0.01 : volume, !!muted);
    }
    const bound = /* @__PURE__ */ new WeakSet();
    document.addEventListener("volumechange", (event) => {
      const video = event.target;
      if (disposed || video !== findVideo() || !bound.has(video) || !desired) return;
      if (!video.ended && !matches(video) && Date.now() < intentUntil) {
        const operation = intentKind === "mute" && (video.muted !== desired.muted || video.volume === 0 || desired.muted) ? "mute" : "volume";
        desired = { volume: video.volume, muted: video.muted };
        report(video, "player", operation);
        return;
      }
      event.stopImmediatePropagation();
      if (matches(video)) report(video, "command");
      else recover();
    }, true);
    function bind(video) {
      bound.add(video);
      apply(video);
    }
    const controls = '[class*="volume" i],[class*="sound" i],[class*="mute" i],[aria-label*="음소거"],[aria-label*="볼륨"],[aria-label*="소리"],[aria-label*="mute" i],[aria-label*="volume" i],[title*="음소거"],[title*="볼륨"],[title*="소리"]';
    function gesture(event) {
      if (!event.isTrusted) return;
      const target = event.target, path = event.composedPath?.() || [target];
      const audioControl = path.some((el) => el.closest?.(controls)) || target.tagName === "VIDEO" && target.controls;
      const genericControl = path.some((el) => el.matches?.('button,[role="button"],input[type="range"]'));
      if (event.type === "keydown" || event.type === "keyup") {
        if (event.altKey || event.ctrlKey || event.metaKey || target.closest?.('textarea,[contenteditable="true"],input:not([type="range"])')) return;
        if (!["m", "M", "ArrowUp", "ArrowDown"].includes(event.key) && !audioControl && !(genericControl && ["Enter", " "].includes(event.key))) return;
      } else if (!audioControl && !genericControl) return;
      intentKind = ["m", "M"].includes(event.key) || path.some((el) => el.matches?.('button,[role="button"]')) ? "mute" : "volume";
      intentUntil = Date.now() + (audioControl ? 800 : 400);
      if (event.type === "pointerdown") pointer = event.pointerId;
    }
    for (const type of ["pointerdown", "click", "input", "change", "keydown", "keyup"]) document.addEventListener(type, gesture, true);
    document.addEventListener("pointermove", (event) => {
      if (event.isTrusted && event.pointerId === pointer) intentUntil = Date.now() + 800;
    }, true);
    document.addEventListener("pointerup", (event) => {
      if (event.pointerId === pointer) {
        pointer = null;
        intentUntil = Date.now() + 250;
      }
    }, true);
    document.addEventListener("pointercancel", () => {
      pointer = null;
      intentUntil = 0;
    }, true);
    window.addEventListener("storage", () => {
      clearIntent();
      recover();
    }, true);
    window.addEventListener("pagehide", () => {
      disposed = true;
      clearIntent();
      clearTimeout(timer);
      timer = null;
    });
    return { bind, setMuted, setVolume };
  } };
})();
